// 定义进程入口函数
#include "logreader.h"
#include "logsender.h"
#include "client.h"
#include "consolesender.h"
#include "socketsender.h"
// 入口函数
int main(void){
    try{
    LogReader reader("./wtmpx","./logins.dat");
//  ConsoleSender sender;
    SocketSender sender("./fail.dat",8888,"172.30.8.20");
    Client client(reader,sender);
    client.dataMine();
    }
    catch(exception& ex){
        cout << ex.what() << endl;
    }
}

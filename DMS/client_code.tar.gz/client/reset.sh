rm wtmpx.2017*
rm *.dat
cp wtmpx.bak wtmpx

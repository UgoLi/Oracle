// 实现日志读取类
using namespace std;
#include "logreader.h"
// 构造函数
LogReader::LogReader(string const& logFile,
        string const& loginsFile)
    :m_logFile(logFile),m_loginsFile(loginsFile){}
// 读取日志
list<MLogRec>& LogReader::readLog() 
    throw (ClientException){
    cout << "读取日志文件开始..." << endl;
    // 备份文件
    backup();
    // 读取登入日志文件
    readLoginsFile();
    // 读取备份文件
    readBackupFile();
    // 匹配
    match();
    // 保存登入日志文件
    saveLoginsFile();
    cout << "读取日志文件完成。" << endl;
    return m_logs;
}
// 备份文件
void LogReader::backup() throw (BackupException){
    cout << "备份文件开始..." << endl;

    cout << "备份文件完成。" << endl;
}
// 读取登入日志文件
void LogReader::readLoginsFile() throw (ReadException){
    cout << "读取登入日志文件开始..." << endl;

    cout << "读取登入日志文件完成。" << endl;
}
// 读取备份文件
void LogReader::readBackupFile() throw (ReadException){
    cout << "读取备份文件开始..." << endl;

    cout << "读取备份文件完成。" << endl;
}
// 匹配登入登出日志
void LogReader::match(){
    cout << "匹配登入登出日志开始..." << endl;

    cout << "匹配登入登出日志完成。" << endl;
}
// 保存登入日志文件
void LogReader::saveLoginsFile() throw (SaveException){
    cout << "保存登入日志文件开始..." << endl;

    cout << "保存登入日志文件完成。" << endl;
}

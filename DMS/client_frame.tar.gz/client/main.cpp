// 定义进程入口函数
#include "logsender.h"
#include "consolesender.h"
#include "logreader.h"
#include "client.h"
// 进程入口函数
int main(void){
    LogReader reader("./wtmpx","./logins.dat");
    ConsoleSender sender;
    Client client(reader,sender);
    client.dataMine();
    return 0;
}

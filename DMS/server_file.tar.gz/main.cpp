// 定义进程入口函数
#include <iostream>
#include "filedao.h"
#include "server.h"
int main(void)
{
    FileDao dao("./dms.db");
    Server server(dao,8888,"127.0.0.1");
    server.dataMine();
    return 0;
}

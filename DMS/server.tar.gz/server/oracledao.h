// 声明数据库数据访问类
#ifndef _ORACLEDAO_H
#define _ORACLEDAO_H
#include "logdao.h"
// Oracle数据访问对象类
class OracleDao : public LogDao{
public:
    // 构造函数
    OracleDao(string const& username,string const&pwd)
        throw(DBException);
    // 析构函数
    ~OracleDao(void);
    void insert(MLogRec const& log) 
        throw(DBException);
};
#endif //_ORACLEDAO_H

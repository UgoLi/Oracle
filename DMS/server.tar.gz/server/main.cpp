// 定义进程入口函数
#include <iostream>
#include "filedao.h"
#include "oracledao.h"
#include "server.h"
int main(void)
{
	try{
//  FileDao dao("./dms.db");
    OracleDao dao("openlab","open123");
	Server server(dao,8888,"172.60.5.81");
    server.dataMine();
	}
	catch(exception& ex)
	{
		cout << ex.what() << endl;
		return -1;
	}
    return 0;
}
